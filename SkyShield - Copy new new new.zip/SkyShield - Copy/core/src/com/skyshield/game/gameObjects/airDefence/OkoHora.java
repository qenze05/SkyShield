package com.skyshield.game.gameObjects.airDefence;

import com.badlogic.gdx.graphics.Texture;

public class OkoHora {
    private float radius;
    private final float[] pos;
    private Texture texture;

    public OkoHora(int mod, float[] pos) {
        this.pos = pos;
    }
}
