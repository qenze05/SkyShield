package com.skyshield.game.gameObjects.buildings;

public class Hitbox {
    private int width;
    private int height;

    public Hitbox(int width, int height) {
        this.width = width;
        this.height = height;
    }

    // Геттери та сеттери для полів width та height


}
